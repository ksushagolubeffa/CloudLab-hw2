from os import getenv

MOUNT_POINT = getenv("MOUNT_POINT")

QUEUE_URL = getenv("QUEUE_URL")
ACCESS_KEY_ID = getenv("ACCESS_KEY_ID")
SECRET_ACCESS_KEY = getenv("SECRET_ACCESS_KEY")
